/* global nodeunit */

nodeunit.run(NPM_TESTS);
